
from django.shortcuts import render

def index(request):
    return render(request,'projet/index.html')

def parier(request):
    return render(request,'projet/parier.html')
