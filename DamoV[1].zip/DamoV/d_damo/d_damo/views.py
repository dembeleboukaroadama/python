from django.shortcuts import render
from .forms import loginForm

#def index(request):
#    return render(request,'index.html')

def parier(request):
    return render(request,'parier.html')
def list(request):

    Equipes= [{'id':1, 'Nom':'Chelsea'},
              {'id':2, 'Nom':'Man city'},
              {'id':3, 'Nom':'Man united'},
              {'id':4, 'Nom':'Arsenal'},
              {'id':5, 'Nom':'Liecester'},
              {'id':6, 'Nom':'Tothenam'},
              {'id':7, 'Nom':'new castle'},
              {'id':8, 'Nom':'Burnley'},
              {'id':9, 'Nom':'Wattford'},
              {'id':10, 'Nom':'Liverpool'},
              {'id':11, 'Nom':'everton'},
              {'id':12, 'Nom':'fulham'},
              {'id':12, 'Nom':'wolveranthon'},
              {'id':12, 'Nom':'Northon'},
              {'id':12, 'Nom':'Crystal Palace'},
              {'id':12, 'Nom':'Southsampton'},
              {'id':12, 'Nom':'Aston villa'},
              {'id':12, 'Nom':'Hull city'},
              {'id':12, 'Nom':'Brigton'},
              {'id':12, 'Nom':'Middlesbourg'}]

    return render(request,'list.html',{'Equipes':Equipes})

def index(request):
    Matchs = [{'id': 1, 'Nom': 'Chelsea','ad':'fulham'},
               {'id': 2, 'Nom': 'Man city','ad':'wolveranthon'},
               {'id': 3, 'Nom': 'Man united','ad':'Northon'},
               {'id': 4, 'Nom': 'Arsenal','ad':'Crystal Palace'},
               {'id': 5, 'Nom': 'Liecester','ad':'Southsampton'},
               {'id': 6, 'Nom': 'Tothenam','ad':'Aston villa'},
               {'id': 7, 'Nom': 'new castle','ad':'Hull city'},
               {'id': 8, 'Nom': 'Burnley','ad':'Brigton'},
               {'id': 9, 'Nom': 'Wattford','ad':'Middlesbourg'},
               {'id': 10, 'Nom': 'Liverpool','ad':'everton'}]



    return render(request,'index.html',{'Matchs':Matchs})

def result(request):
    resultats=[{'id': 1, 'eq1':'Chelsea','eq2':'fulham','score':'2-0'},
               {'id': 2, 'eq1':'Man city','eq2':'wolveranthon','score':'3-1'},
               {'id': 3, 'eq1':'Man united','eq2':'Northon','score':'2-1'},
               {'id': 4, 'eq1': 'Arsenal','eq2':'Crystal Palace','score':'1-1'},
               {'id': 5, 'eq1': 'Liecester','eq2':'Southsampton','score':'2-0'},
               {'id': 6, 'eq1': 'Tothenam','eq2':'Aston villa','score':'3-1'},
               {'id': 7, 'eq1': 'new castle','eq2':'Hull city','score':'3-0'},
               {'id': 8, 'eq1': 'Burnley','eq2':'Brigton','score':'3-1'},
               {'id': 9, 'eq1': 'Wattford','eq2':'Middlesbourg','score':'2-1'},
               {'id': 10, 'eq1': 'Liverpool','eq2':'everton','score':'0-0'}]
    return render(request,'resultats.html',{'resultats':resultats})

def login(request):
    username="not logged in"
    if request.method=='post':
        MyLoginForm =loginForm(request.POST)
        if MyLoginForm.is_valid():
            username=MyLoginForm.cleaned_data['username']

        else:
            MyLoginForm=loginForm()
            f = open('paries.txt', 'w+')
            w = f.write(username)
        return render(request,'parier.html')






