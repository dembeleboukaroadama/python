from django.db import models


class Equipe(models.Moden):
    Nom=models.CharField(max_length=100)